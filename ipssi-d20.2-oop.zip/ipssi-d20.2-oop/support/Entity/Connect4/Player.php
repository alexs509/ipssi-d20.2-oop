<?php

declare(strict_types=1);

namespace Support\Entity\Connect4;

final class Player implements Participant
{
    
}