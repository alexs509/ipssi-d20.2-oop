<?php

declare(strict_types=1);

namespace Support\Entity;


interface Participant
{

}
