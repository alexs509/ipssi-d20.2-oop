<?php

declare(strict_types=1);

namespace App\Connect4\Entity;

final class Piece
{
    protected function _dropPiece(){
		
		//Check if total moves reached. (Recursive baseline)
		if( $this->_moves >= ( $this->getRows() * $this->getColumns() )) {
			
			//No winner then =(
			$this->_showNoWinnerMessage();
			
			return false; 
		}
		
		//Random column chosen for placing chips
		$_target_col = rand(0, $this->getColumns()-1);
		$_current_board = $this->_getCurrentBoard();
		
		for( $row = $this->getRows()-1; $row>=0; $row-- ){
			
			//If slot is currently empty
			if( $_current_board[$row][$_target_col] === -1 ){
				
				//Set slot to current player
				$_current_board[$row][$_target_col] = $this->_getCurrentPlayer();
				
				//Update the no. of moves, might wana setter/getter this
				$this->_moves++;
				
				//Update the board
				$this->_setCurrentBoard($_current_board);
				
				//Print current board
				$this->_printBoard();
				
				//Check for winner
				if( $this->_checkForWinner( $row, $_target_col ) ){
					
					//If winner is found
					$this->_showWinnerMessage();
					
					return false;
					
				}else{
					
					//Else continue the game
					
					//Change player
					$this->_togglePlayer();
					
					//Drop the piece
					$this->_dropPiece();
					
				}
				
				//exit once a piece is dropped for this move
				return false;
				
			} 
			
		}
		
		//If it comes to here, it means no slots are empty (column is full). Redo move again
		$this->_dropPiece();
		
	}
}