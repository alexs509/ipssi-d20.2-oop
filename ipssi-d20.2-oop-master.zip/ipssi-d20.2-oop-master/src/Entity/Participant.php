<?php

namespace App\Connect4\Entity;

use Support\Entity\Participant as ParticipantInterface;

interface Participant extends ParticipantInterface
{

}