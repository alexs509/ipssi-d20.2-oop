<?php

declare(strict_types=1);

namespace App\Connect4\Service;

use App\Connect4\Entity\Piece;
use App\Connect4\Entity\Player;
use App\Connect4\Exception\TooManyPlayers;
use App\Game as GameInterface;
use RuntimeException;
use Support\Renderer\Output;
use App\Connect4\Entity\Participant;
use Support\Service\RandomValue;

final class Game implements GameInterface
{
    /**
	 * Default rows is 6
	 * 
	 * @var int
	 */
	protected $_rows = 6;

	/**
	 * Default columns is 6
	 * 
	 * @var int
	 */
	protected $_columns = 6;
	
	/**
	 * The board array to store information about player's pieces
	 * 
	 * @var array
	 */
	protected $_board_array = array();
	
	/**
	 * Player 1 = 1, Player 2 = 2, No Player Selected = 0
	 * 
	 * @var int
	 */
	
	protected $_current_player = 0;
	
	/**
	 * Track moves executed by both players.
	 * 
	 * @var int
	 */
	protected $_moves = 0;
	
	
	
	/**
	 * CONSTRUCTOR
	 * Starts the game on new instance
	 * @param int $rows
	 * @param int $cols
	 */
	function __construct( $rows = 7, $cols = 7){
		
		$this->_setDimensions( $rows, $cols );
		
		$this->_initGame();
	}
	
	/**
	 * Creates or resets a 2d board array
	 * 
	 * @desc This is a better upgrade for initializeGameBoard method as described in the assignment.
	 * Please note this method will not include a parameter since it creates the 2d array. (contrary to requirements)
	 * This method effectively creates/resets the gameboard, assigning values while creating, looping only once.
	 * 
	 * Alternatively, the assignment assumes you will use a static 6x6 board, in that case, which you can create a static 2d array and pass it to this function.
	 */
	protected function _initializeGameBoard(){
	
		//resets the board array
		$_board_array = array();
		
		for($i = 0; $i < $this->getRows() ; $i ++ ){
	
			$_board_array[$i] = array();
			
			for($j = 0; $j < $this->getColumns() ; $j ++ ){
			
				//-1 means this slot is unoccupied.
				$_board_array[$i][$j] = -1;
			
			}
	
		}
		
		$this->_setCurrentBoard($_board_array);
		
	}
}